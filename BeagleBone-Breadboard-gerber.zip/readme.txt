Date : 11/10/2011 

PCB VIET NAM
EMAIL : info@pcbvn.com
        nampth@yahoo.com
Cell phone : +84908222784

README for gerber_bonebreadboard_nov10.zip

Files contained in the zip file:

README.1st     				This file
layer1_top   				Layer 1
layer2_bot				Layer 2
smask_top   				Soldermask Layer 1 Side (Component)
smask_bot    				Soldermask Layer 2 Side 
silk_top 				Silk Screen Layer 1 side
fab	    				Fabrication Drawing Page 1(for Ref. ONLY)
assy_top	      			Assembly Drawing (for Ref. ONLY)
ncdrill-1-2.drl   			Drill tape, Layer 1 through 2
nc_param.txt 				Drill tape setup file
ncdrill.log    				Drill tape composite file (for Reference ONLY)
BoneBreadboard_10nov.ipc   		IPC-D-356 netlist (for Checking ONLY)
art_param.txt  				Artwork Format File (for Ref. ONLY)
placed_component			Placement file for Assembly (for Ref. Only)
netlist_allegro 			Allegro Netlist (for Ref. Only)
BoneBreadboard_10nov.brd		File layout Allegro

Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.

